
import TextSummarization from './TextSummarization'

function QuickApps() {
  return (
      <section className="Core-capabilities">
        <div className='container'>          
          <div className='block-container'>
              <h2 className='capability-title'>Quick App — Mini tools hub</h2>
              <p className='short-description'>Instantly access lightweight tools for common tasks.</p>
              <div className='capabilities'>
                <TextSummarization />
                <TextSummarization />
                <TextSummarization />
              </div>
          </div>
        </div>
      </section>
  );
}

export default QuickApps;
