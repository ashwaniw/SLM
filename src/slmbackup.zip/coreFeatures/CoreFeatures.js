
import PIIPHI from './PIIPHI';

function CoreFeatures() {
  return (
      <section className="Core-capabilities">
        <div className='container'>
          <div className='block-container'>
              <h2 className='capability-title'>Core Features</h2>
              <p className='short-description'>All-in-one platform for content intelligence across text, audio, image & video.</p>
              <div className='capabilities'>
                <PIIPHI />
                <PIIPHI />
                <PIIPHI />
                <PIIPHI />
                <PIIPHI />
              </div>
          </div>          
        </div>
      </section>
  );
}

export default CoreFeatures;
